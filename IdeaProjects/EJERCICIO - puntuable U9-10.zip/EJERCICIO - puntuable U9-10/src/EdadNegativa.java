public class EdadNegativa extends Exception{
    public EdadNegativa(String message) {super(message);}
}
