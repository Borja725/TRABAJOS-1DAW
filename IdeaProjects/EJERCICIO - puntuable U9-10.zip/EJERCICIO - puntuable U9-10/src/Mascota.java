public interface Mascota {
    String getNombre();

    void setNombre(String nombre);

    void jugar(String nombre);
}
